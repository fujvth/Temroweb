import { MessageCircle } from "lucide-react";

const WhatsAppButton = () => {
  const phoneNumber = "9779706107325";
  const message = "Hello! I'm interested in your web design services.";
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50 flex items-center gap-2.5 bg-[#25D366] text-white px-4 sm:px-5 py-3 sm:py-3.5 rounded-full shadow-xl hover:bg-[#128C7E] transition-all duration-300 hover:scale-110 animate-fade-in group"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle size={24} className="group-hover:rotate-12 transition-transform" />
      <span className="hidden sm:inline font-semibold text-sm sm:text-base">Let's Chat</span>
    </a>
  );
};

export default WhatsAppButton;
