import { Code, Smartphone, Search, Globe, Palette, Headphones } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";

const Services = () => {
  const services = [
    {
      icon: Code,
      title: "Website Development",
      description: "Custom websites built with modern technologies, tailored to your business needs and goals.",
      features: ["Static & Dynamic Sites", "E-commerce Solutions", "Content Management Systems"]
    },
    {
      icon: Smartphone,
      title: "Responsive Design",
      description: "Mobile-first designs that look perfect on all devices, from smartphones to desktop computers.",
      features: ["Mobile Optimization", "Cross-browser Compatible", "Touch-friendly Interface"]
    },
    {
      icon: Search,
      title: "SEO Optimization",
      description: "Get found on Google with our comprehensive SEO services to improve your search rankings.",
      features: ["Keyword Research", "On-page SEO", "Performance Optimization"]
    },
    {
      icon: Globe,
      title: "Domain & Hosting",
      description: "Complete domain registration and hosting setup assistance for your website.",
      features: ["Free .np Domain Help", "SSL Certificate Setup", "Hosting Configuration"]
    },
    {
      icon: Palette,
      title: "Custom Design",
      description: "Beautiful, modern designs that reflect your brand identity and engage your visitors.",
      features: ["Brand Integration", "Custom Graphics", "UI/UX Design"]
    },
    {
      icon: Headphones,
      title: "Support & Maintenance",
      description: "Ongoing support to keep your website running smoothly with regular updates and fixes.",
      features: ["Technical Support", "Content Updates", "Bug Fixes"]
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-16 sm:py-20 md:py-28 bg-gradient-to-b from-primary/10 via-primary/5 to-transparent">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center animate-fade-in">
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-5 md:mb-7">Our Services</h1>
              <p className="text-base sm:text-lg md:text-xl text-muted-foreground px-4 leading-relaxed">
                Comprehensive web solutions to help your business succeed online
              </p>
            </div>
          </div>
        </section>

        {/* Services Grid */}
        <section className="py-12 sm:py-16 md:py-20">
          <div className="container mx-auto px-4">
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 max-w-6xl mx-auto">
              {services.map((service, index) => {
                const Icon = service.icon;
                return (
                  <Card 
                    key={index} 
                    className="hover:shadow-xl hover:border-primary/50 transition-all duration-300 animate-fade-up group"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <CardHeader>
                      <div className="p-3 rounded-xl bg-primary/10 w-fit mb-4 group-hover:bg-primary/20 transition-colors">
                        <Icon className="text-primary" size={36} />
                      </div>
                      <CardTitle className="text-lg sm:text-xl">{service.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">{service.description}</p>
                      <ul className="space-y-2.5">
                        {service.features.map((feature, idx) => (
                          <li key={idx} className="text-sm flex items-center gap-2.5">
                            <span className="text-primary font-bold text-lg">✓</span>
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* Process Section */}
        <section className="py-16 sm:py-20 md:py-24 bg-gradient-to-b from-muted/50 to-transparent">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto">
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-10 sm:mb-14 md:mb-16 text-center animate-fade-in">Our Process</h2>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
                <div className="text-center p-6 rounded-xl hover:bg-background transition-all duration-300 animate-fade-up group" style={{ animationDelay: '0s' }}>
                  <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-primary to-accent text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-5 text-2xl sm:text-3xl font-bold shadow-lg group-hover:scale-110 transition-transform">
                    1
                  </div>
                  <h3 className="font-bold text-lg sm:text-xl mb-3">Consultation</h3>
                  <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                    We discuss your needs and goals
                  </p>
                </div>

                <div className="text-center p-6 rounded-xl hover:bg-background transition-all duration-300 animate-fade-up group" style={{ animationDelay: '0.1s' }}>
                  <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-primary to-accent text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-5 text-2xl sm:text-3xl font-bold shadow-lg group-hover:scale-110 transition-transform">
                    2
                  </div>
                  <h3 className="font-bold text-lg sm:text-xl mb-3">Planning</h3>
                  <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                    We create a detailed project plan
                  </p>
                </div>

                <div className="text-center p-6 rounded-xl hover:bg-background transition-all duration-300 animate-fade-up group" style={{ animationDelay: '0.2s' }}>
                  <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-primary to-accent text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-5 text-2xl sm:text-3xl font-bold shadow-lg group-hover:scale-110 transition-transform">
                    3
                  </div>
                  <h3 className="font-bold text-lg sm:text-xl mb-3">Development</h3>
                  <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                    We build your website
                  </p>
                </div>

                <div className="text-center p-6 rounded-xl hover:bg-background transition-all duration-300 animate-fade-up group" style={{ animationDelay: '0.3s' }}>
                  <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-primary to-accent text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-5 text-2xl sm:text-3xl font-bold shadow-lg group-hover:scale-110 transition-transform">
                    4
                  </div>
                  <h3 className="font-bold text-lg sm:text-xl mb-3">Launch</h3>
                  <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                    Your website goes live
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Start Your Project?</h2>
              <p className="text-lg text-muted-foreground mb-8">
                Let's discuss how we can help you achieve your online goals.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" asChild>
                  <Link to="/contact">Get a Quote</Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link to="/portfolio">View Our Work</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default Services;
