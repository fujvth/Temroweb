import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";
import portfolio1 from "@/assets/portfolio-1.jpg";
import portfolio2 from "@/assets/portfolio-2.jpg";
import portfolio3 from "@/assets/portfolio-3.jpg";
import portfolio4 from "@/assets/portfolio-4.jpg";
import portfolio5 from "@/assets/portfolio-5.jpg";
import portfolio6 from "@/assets/portfolio-6.jpg";

const Portfolio = () => {
  const projects = [
    {
      title: "E-Commerce Fashion Store",
      category: "E-Commerce",
      image: portfolio1,
      description: "A modern online store with shopping cart and payment integration"
    },
    {
      title: "Restaurant Website",
      category: "Restaurant",
      image: portfolio2,
      description: "Beautiful restaurant website with menu and reservation system"
    },
    {
      title: "Medical Clinic",
      category: "Healthcare",
      image: portfolio3,
      description: "Professional healthcare website with appointment booking"
    },
    {
      title: "Photography Portfolio",
      category: "Portfolio",
      image: portfolio4,
      description: "Stunning portfolio website for a professional photographer"
    },
    {
      title: "Corporate Business",
      category: "Corporate",
      image: portfolio5,
      description: "Professional corporate website with team and services showcase"
    },
    {
      title: "Educational Institute",
      category: "Education",
      image: portfolio6,
      description: "Vibrant school website with course listings and galleries"
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-16 md:py-20 bg-gradient-to-b from-primary/5 to-transparent">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 md:mb-6 animate-fade-in">Our Work</h1>
              <p className="text-base sm:text-lg md:text-xl text-muted-foreground px-4 animate-fade-up">
                Explore our portfolio of successful projects. Over 200 websites delivered to happy clients across Nepal.
              </p>
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="py-8 md:py-12 bg-muted">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 max-w-4xl mx-auto text-center">
              <div className="p-4 animate-fade-up" style={{ animationDelay: '0s' }}>
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">200+</div>
                <div className="text-xs sm:text-sm text-muted-foreground">Projects Completed</div>
              </div>
              <div className="p-4 animate-fade-up" style={{ animationDelay: '0.1s' }}>
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">3+</div>
                <div className="text-xs sm:text-sm text-muted-foreground">Years Experience</div>
              </div>
              <div className="p-4 animate-fade-up" style={{ animationDelay: '0.2s' }}>
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">100%</div>
                <div className="text-xs sm:text-sm text-muted-foreground">Client Satisfaction</div>
              </div>
              <div className="p-4 animate-fade-up" style={{ animationDelay: '0.3s' }}>
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">3-10</div>
                <div className="text-xs sm:text-sm text-muted-foreground">Days Delivery</div>
              </div>
            </div>
          </div>
        </section>

        {/* Portfolio Grid */}
        <section className="py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 max-w-7xl mx-auto">
              {projects.map((project, index) => (
                <Card 
                  key={index} 
                  className="overflow-hidden hover:shadow-xl transition-all duration-300 group animate-fade-up"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="relative aspect-video overflow-hidden bg-muted">
                    <img 
                      src={project.image} 
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <CardContent className="p-4 md:p-6">
                    <div className="inline-block px-3 py-1 bg-primary/10 text-primary text-xs md:text-sm rounded-full mb-3">
                      {project.category}
                    </div>
                    <h3 className="text-lg md:text-xl font-semibold mb-2">{project.title}</h3>
                    <p className="text-muted-foreground text-sm">{project.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-12 md:py-16 bg-muted">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl sm:text-3xl font-bold mb-8 md:mb-12 text-center animate-fade-in">What Our Clients Say</h2>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6 md:gap-8 max-w-6xl mx-auto">
              <Card className="hover:shadow-lg transition-shadow animate-fade-up" style={{ animationDelay: '0s' }}>
                <CardContent className="p-4 md:p-6">
                  <div className="flex mb-4">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className="text-yellow-500 text-lg">★</span>
                    ))}
                  </div>
                  <p className="text-sm md:text-base text-muted-foreground mb-4 leading-relaxed">
                    "Excellent service! They delivered my restaurant website on time and within budget. Highly recommend!"
                  </p>
                  <p className="text-sm md:text-base font-semibold">- Ram Sharma, Restaurant Owner</p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow animate-fade-up" style={{ animationDelay: '0.15s' }}>
                <CardContent className="p-4 md:p-6">
                  <div className="flex mb-4">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className="text-yellow-500 text-lg">★</span>
                    ))}
                  </div>
                  <p className="text-sm md:text-base text-muted-foreground mb-4 leading-relaxed">
                    "Very professional and affordable. My clinic's website has helped us reach more patients."
                  </p>
                  <p className="text-sm md:text-base font-semibold">- Dr. Sita Rai, Clinic Owner</p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow animate-fade-up sm:col-span-2 md:col-span-1" style={{ animationDelay: '0.3s' }}>
                <CardContent className="p-4 md:p-6">
                  <div className="flex mb-4">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className="text-yellow-500 text-lg">★</span>
                    ))}
                  </div>
                  <p className="text-sm md:text-base text-muted-foreground mb-4 leading-relaxed">
                    "Great work! The team understood my vision and created a beautiful portfolio website."
                  </p>
                  <p className="text-sm md:text-base font-semibold">- Hari Thapa, Photographer</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-12 md:py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center animate-fade-in">
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 md:mb-6 px-4">Ready to Join Our Success Stories?</h2>
              <p className="text-base md:text-lg text-muted-foreground mb-6 md:mb-8 px-4">
                Let's create an amazing website for your business. Starting from just Rs. 3,999!
              </p>
              <Button size="lg" asChild className="animate-scale-in">
                <Link to="/contact">Start Your Project</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default Portfolio;
