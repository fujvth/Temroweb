import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle2, Users, Award, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";

const Home = () => {
  const plans = [
    {
      name: "Basic Plan",
      price: "Rs. 3,999",
      description: "Perfect for startups or personal brands",
      features: [
        "1-page static website (Home + Contact)",
        "Mobile responsive design",
        "Free .np domain setup help",
        "3 Revisions",
        "Delivery in 3 days"
      ],
      bestFor: "Personal websites, small shops, or freelancers",
      color: "border-primary"
    },
    {
      name: "Standard Plan",
      price: "Rs. 7,999",
      description: "Ideal for small businesses & growing brands",
      features: [
        "Up to 5 pages (Home, About, Services, Gallery, Contact)",
        "Mobile & tablet responsive",
        "WhatsApp & Messenger chat integration",
        "Free SSL setup",
        "5 Revisions",
        "Delivery in 5–7 days"
      ],
      bestFor: "Cafes, clinics, schools, or small companies",
      color: "border-accent",
      popular: true
    },
    {
      name: "Premium Plan",
      price: "Rs. 14,999",
      description: "Professional websites for serious businesses",
      features: [
        "Up to 10 pages (includes Blog, Portfolio, and more)",
        "Custom animations and design",
        "SEO optimization",
        "Domain & Hosting setup help",
        "Admin panel or CMS (optional)",
        "Unlimited revisions for 1 month",
        "Delivery in 7–10 days"
      ],
      bestFor: "Growing businesses and professional services",
      color: "border-primary"
    }
  ];

  const stats = [
    { icon: Users, label: "Happy Clients", value: "200+" },
    { icon: Award, label: "Years Experience", value: "3+" },
    { icon: Clock, label: "Quick Delivery", value: "3-10 Days" }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary/10 via-primary/5 to-transparent">
        <div className="absolute inset-0 bg-grid-white/[0.02] pointer-events-none" />
        <div className="container mx-auto px-4 py-20 sm:py-24 md:py-32 lg:py-40">
          <div className="max-w-4xl mx-auto text-center relative">
            <div className="inline-block mb-4 animate-fade-in">
              <span className="bg-primary/10 text-primary px-4 py-1.5 rounded-full text-xs sm:text-sm font-semibold">
                🏆 Nepal's #1 Affordable Web Service
              </span>
            </div>
            <h1 className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-5 md:mb-7 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent animate-fade-in leading-tight">
              Beautiful Websites That Don't Break the Bank
            </h1>
            <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-muted-foreground mb-8 md:mb-10 max-w-3xl mx-auto animate-fade-up leading-relaxed px-2">
              Professional websites from just <span className="text-primary font-semibold">Rs. 3,999</span>. Join 200+ happy clients who trusted us to build their online presence.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center animate-scale-in px-4">
              <Button size="lg" asChild className="w-full sm:w-auto text-base h-12 sm:h-14 shadow-lg hover:shadow-xl transition-all">
                <Link to="/contact">
                  Get Started <ArrowRight className="ml-2" size={20} />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild className="w-full sm:w-auto text-base h-12 sm:h-14 border-2 hover:bg-primary/5">
                <Link to="/portfolio">View Our Work</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-10 sm:py-12 md:py-16 bg-muted/50 border-y border-border">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8 md:gap-10">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div 
                  key={index} 
                  className="flex flex-col items-center justify-center gap-3 p-6 rounded-xl hover:bg-background transition-all duration-300 hover:shadow-md group animate-fade-up"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="p-4 rounded-full bg-primary/10 group-hover:bg-primary/20 transition-colors">
                    <Icon className="text-primary" size={32} />
                  </div>
                  <div className="text-center">
                    <div className="text-3xl sm:text-4xl md:text-5xl font-bold mb-1">{stat.value}</div>
                    <div className="text-sm sm:text-base text-muted-foreground font-medium">{stat.label}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 sm:py-20 md:py-28">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10 sm:mb-12 md:mb-16 animate-fade-in">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 md:mb-5">Choose Your Perfect Plan</h2>
            <p className="text-muted-foreground text-base sm:text-lg md:text-xl max-w-2xl mx-auto px-4">Affordable pricing for businesses of all sizes in Nepal</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8 max-w-7xl mx-auto">
            {plans.map((plan, index) => (
              <Card 
                key={index} 
                className={`relative ${plan.color} border-2 ${plan.popular ? 'shadow-xl lg:scale-105 bg-gradient-to-br from-background to-primary/5' : 'shadow-md'} hover:shadow-2xl transition-all duration-300 animate-fade-up`}
                style={{ animationDelay: `${index * 0.15}s` }}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-10">
                    <span className="bg-gradient-to-r from-primary to-accent text-primary-foreground px-5 py-1.5 rounded-full text-xs sm:text-sm font-bold shadow-lg animate-pulse-slow">
                      ⭐ Most Popular
                    </span>
                  </div>
                )}
                <CardHeader className="pb-4">
                  <CardTitle className="text-xl sm:text-2xl">{plan.name}</CardTitle>
                  <CardDescription className="text-sm sm:text-base">{plan.description}</CardDescription>
                  <div className="mt-5 pt-5 border-t border-border">
                    <span className="text-4xl sm:text-5xl font-bold text-primary">{plan.price}</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-5">
                  <ul className="space-y-3">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-3">
                        <CheckCircle2 className="text-primary shrink-0 mt-0.5" size={20} />
                        <span className="text-sm sm:text-base leading-relaxed">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="p-4 bg-gradient-to-br from-muted to-muted/50 rounded-lg border border-border">
                    <p className="text-xs sm:text-sm font-semibold mb-1">Perfect for:</p>
                    <p className="text-xs sm:text-sm text-muted-foreground">{plan.bestFor}</p>
                  </div>
                </CardContent>
                <CardFooter className="pt-6">
                  <Button className="w-full h-11 sm:h-12 text-sm sm:text-base font-semibold" variant={plan.popular ? "default" : "outline"} asChild>
                    <Link to="/contact">Choose Plan →</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-12 md:py-20 bg-muted">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8 md:mb-12 animate-fade-in">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-3 md:mb-4">Why Choose Temro Web?</h2>
            <p className="text-muted-foreground text-base md:text-lg px-4">We deliver quality websites at prices you can afford</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 max-w-6xl mx-auto">
            <Card className="hover:shadow-lg transition-all duration-300 animate-fade-up" style={{ animationDelay: '0s' }}>
              <CardHeader>
                <CardTitle className="text-lg md:text-xl">Affordable Pricing</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Starting from just Rs. 3,999, we offer the most competitive prices in Nepal without compromising quality.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-all duration-300 animate-fade-up" style={{ animationDelay: '0.1s' }}>
              <CardHeader>
                <CardTitle className="text-lg md:text-xl">Fast Delivery</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Get your website ready in just 3-10 days depending on your chosen plan.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-all duration-300 animate-fade-up" style={{ animationDelay: '0.2s' }}>
              <CardHeader>
                <CardTitle className="text-lg md:text-xl">200+ Happy Clients</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Join our growing family of satisfied clients who trusted us with their online presence.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-all duration-300 animate-fade-up" style={{ animationDelay: '0.3s' }}>
              <CardHeader>
                <CardTitle className="text-lg md:text-xl">3+ Years Experience</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Our experienced team has been delivering quality websites for over 3 years.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 md:py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center animate-fade-in">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 md:mb-6 px-4">Ready to Get Started?</h2>
            <p className="text-base md:text-lg text-muted-foreground mb-6 md:mb-8 px-4">
              Let's build your dream website together. Contact us today for a free consultation.
            </p>
            <Button size="lg" asChild className="animate-scale-in">
              <Link to="/contact">
                Start Your Project <ArrowRight className="ml-2" size={20} />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default Home;
