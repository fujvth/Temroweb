import { Target, Eye, Award, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";

const About = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-16 md:py-20 bg-gradient-to-b from-primary/5 to-transparent">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 md:mb-6 animate-fade-in">About Temro Web</h1>
              <p className="text-base sm:text-lg md:text-xl text-muted-foreground px-4 animate-fade-up">
                Nepal's most trusted and affordable website service provider, dedicated to helping businesses establish their online presence.
              </p>
            </div>
          </div>
        </section>

        {/* Our Story */}
        <section className="py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-2xl sm:text-3xl font-bold mb-4 md:mb-6 text-center animate-fade-in">Our Story</h2>
              <p className="text-muted-foreground text-base md:text-lg mb-4 leading-relaxed animate-fade-up">
                Founded with a mission to make professional websites accessible to every Nepali business, Temro Web has grown to become Nepal's most affordable website service provider. Over the past 3 years, we've helped more than 200 businesses, entrepreneurs, and professionals establish their digital presence.
              </p>
              <p className="text-muted-foreground text-base md:text-lg leading-relaxed animate-fade-up" style={{ animationDelay: '0.2s' }}>
                We believe that every business deserves a professional website, regardless of their budget. That's why we've designed our services to be not only affordable but also high-quality, ensuring that our clients get the best value for their investment.
              </p>
            </div>
          </div>
        </section>

        {/* Mission & Vision */}
        <section className="py-12 md:py-16 bg-muted">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-6 md:gap-8 max-w-5xl mx-auto">
              <Card className="animate-fade-up hover:shadow-lg transition-shadow" style={{ animationDelay: '0s' }}>
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <Target className="text-primary" size={32} />
                    <CardTitle className="text-2xl">Our Mission</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    To empower Nepali businesses with affordable, professional websites that help them grow and succeed in the digital age. We're committed to delivering quality web solutions that drive results.
                  </p>
                </CardContent>
              </Card>

              <Card className="animate-fade-up hover:shadow-lg transition-shadow" style={{ animationDelay: '0.15s' }}>
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <Eye className="text-primary" size={32} />
                    <CardTitle className="text-xl md:text-2xl">Our Vision</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    To be the leading web service provider in Nepal, known for our affordability, quality, and customer satisfaction. We envision a future where every Nepali business has a strong online presence.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="py-12 md:py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl sm:text-3xl font-bold mb-8 md:mb-12 text-center animate-fade-in">Why Businesses Choose Us</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 max-w-6xl mx-auto">
              <Card className="hover:shadow-lg transition-all duration-300 animate-fade-up" style={{ animationDelay: '0s' }}>
                <CardHeader>
                  <Users className="text-primary mb-2" size={36} />
                  <CardTitle className="text-lg md:text-xl">200+ Happy Clients</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    We've successfully delivered websites to over 200 satisfied clients across Nepal.
                  </p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-all duration-300 animate-fade-up" style={{ animationDelay: '0.1s' }}>
                <CardHeader>
                  <Award className="text-primary mb-2" size={36} />
                  <CardTitle className="text-lg md:text-xl">3+ Years Experience</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Our team brings years of expertise in web development and design.
                  </p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-all duration-300 animate-fade-up" style={{ animationDelay: '0.2s' }}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg md:text-xl">
                    💰 Affordable Prices
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Starting from just Rs. 3,999, we offer Nepal's most competitive pricing.
                  </p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-all duration-300 animate-fade-up" style={{ animationDelay: '0.3s' }}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg md:text-xl">
                    ⚡ Fast Delivery
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Get your website ready in just 3-10 days with our efficient process.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Our Values */}
        <section className="py-12 md:py-16 bg-muted">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl sm:text-3xl font-bold mb-8 md:mb-12 text-center animate-fade-in">Our Core Values</h2>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6 md:gap-8 max-w-5xl mx-auto">
              <div className="text-center p-4 animate-fade-up" style={{ animationDelay: '0s' }}>
                <div className="w-14 h-14 md:w-16 md:h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 hover:scale-110 transition-transform">
                  <span className="text-2xl md:text-3xl">🎯</span>
                </div>
                <h3 className="text-lg md:text-xl font-semibold mb-2">Quality First</h3>
                <p className="text-sm md:text-base text-muted-foreground">
                  We never compromise on quality, ensuring every website meets professional standards.
                </p>
              </div>

              <div className="text-center p-4 animate-fade-up" style={{ animationDelay: '0.15s' }}>
                <div className="w-14 h-14 md:w-16 md:h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 hover:scale-110 transition-transform">
                  <span className="text-2xl md:text-3xl">🤝</span>
                </div>
                <h3 className="text-lg md:text-xl font-semibold mb-2">Customer First</h3>
                <p className="text-sm md:text-base text-muted-foreground">
                  Your satisfaction is our priority. We work closely with you to bring your vision to life.
                </p>
              </div>

              <div className="text-center p-4 animate-fade-up sm:col-span-2 md:col-span-1" style={{ animationDelay: '0.3s' }}>
                <div className="w-14 h-14 md:w-16 md:h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 hover:scale-110 transition-transform">
                  <span className="text-2xl md:text-3xl">💡</span>
                </div>
                <h3 className="text-lg md:text-xl font-semibold mb-2">Innovation</h3>
                <p className="text-sm md:text-base text-muted-foreground">
                  We stay updated with the latest web technologies to deliver modern solutions.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default About;
